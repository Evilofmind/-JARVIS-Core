package com.personal.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

data class Notice(val app: String, val title: String, val body: String)

object NoticeStore {
    val items = CopyOnWriteArrayList<Notice>()
}

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isNotBlank() || body.isNotBlank()) {
            NoticeStore.items.add(0, Notice(sbn.packageName, title, body))
            while (NoticeStore.items.size > 30) NoticeStore.items.removeAt(NoticeStore.items.lastIndex)
        }
    }
}
