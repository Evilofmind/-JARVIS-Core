package com.personal.jarvis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

private val Bg = Color(0xFF050B14)
private val Panel = Color(0xFF0D1A2B)
private val Cyan = Color(0xFF55DDF5)
private val Muted = Color(0xFF9BB2C9)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var voiceResult: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        requestRuntimePermissions()
        setContent { JarvisScreen(this) }
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.RECORD_AUDIO)
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
    }

    fun speak(text: String) {
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    fun listen(onText: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onError("No speech recognition service is installed. Install an offline-capable recognizer or type your command.")
            return
        }
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        voiceResult = onText
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onError("Voice input failed (code $error). Try again or type instead.") }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (phrase.isNullOrBlank()) onError("I didn't catch that.") else voiceResult?.invoke(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        speech?.startListening(intent)
    }

    fun processCommand(command: String, endpoint: String, haUrl: String, haToken: String, callback: (String) -> Unit) {
        val lower = command.lowercase(Locale.US).trim()
        when {
            lower.startsWith("open ") -> {
                val name = lower.removePrefix("open ").trim()
                val packageName = when {
                    "youtube" in name -> "com.google.android.youtube"
                    "whatsapp" in name -> "com.whatsapp"
                    "settings" in name -> "com.android.settings"
                    "maps" in name || "google maps" in name -> "com.google.android.apps.maps"
                    else -> null
                }
                val launch = packageName?.let { packageManager.getLaunchIntentForPackage(it) }
                if (launch != null) {
                    startActivity(launch)
                    callback("Opening $name.")
                } else callback("I couldn't launch $name. Try YouTube, WhatsApp, Maps, or Settings.")
            }
            lower.startsWith("remind me in ") -> {
                val match = Regex("""remind me in\s+(\d+)\s+(second|seconds|minute|minutes|hour|hours)\s+(?:to\s+)?(.+)""").find(lower)
                if (match == null) callback("Try: remind me in 10 minutes to drink water.")
                else {
                    val amount = match.groupValues[1].toLong()
                    val unit = match.groupValues[2]
                    val text = match.groupValues[3]
                    val multiplier = if (unit.startsWith("second")) 1000L else if (unit.startsWith("hour")) 3600000L else 60000L
                    scheduleReminder(text, amount * multiplier)
                    callback("Reminder set for $text in $amount $unit.")
                }
            }
            lower.contains("read notifications") || lower.contains("read my notifications") -> {
                val latest = NoticeStore.items.take(5)
                callback(if (latest.isEmpty()) "No notifications captured yet. Enable JARVIS notification access in Android Settings." else
                    latest.joinToString(". ") { "${it.app.substringAfterLast('.')}: ${it.title}. ${it.body}" })
            }
            lower.startsWith("remember ") -> {
                val item = command.substringAfter("remember ", "").trim()
                if (item.isNotBlank()) {
                    val prefs = getSharedPreferences("jarvis_memory", MODE_PRIVATE)
                    val old = prefs.getString("notes", "").orEmpty()
                    prefs.edit().putString("notes", (old + "\n• " + item).takeLast(12000)).apply()
                    callback("Saved to local memory.")
                } else callback("Tell me what you want me to remember.")
            }
            lower.contains("what do you remember") || lower.contains("show memory") -> {
                callback(getSharedPreferences("jarvis_memory", MODE_PRIVATE).getString("notes", "").orEmpty().ifBlank { "Your memory is empty. Say: remember that I prefer concise answers." })
            }
            lower.startsWith("home ") -> controlHome(command, haUrl, haToken, callback)
            else -> askLocalModel(command, endpoint, callback)
        }
    }

    private fun scheduleReminder(text: String, delayMs: Long) {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("text", text)
        val pi = PendingIntent.getBroadcast(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + delayMs.coerceAtLeast(1000L)
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else alarm.set(AlarmManager.RTC_WAKEUP, at, pi)
    }

    private fun controlHome(command: String, haUrl: String, token: String, callback: (String) -> Unit) {
        val match = Regex("""home\s+(on|off)\s+([a-zA-Z0-9_.]+)""", RegexOption.IGNORE_CASE).find(command)
        if (match == null) {
            callback("For Home Assistant, use: home on light.living_room or home off switch.plug. Configure your local server URL and token in the app.")
            return
        }
        if (haUrl.isBlank() || token.isBlank()) {
            callback("Home Assistant isn't configured yet. Enter its local URL and long-lived access token in the settings fields.")
            return
        }
        val action = if (match.groupValues[1].equals("on", true)) "turn_on" else "turn_off"
        val entity = match.groupValues[2]
        executor.execute {
            try {
                val url = URL(haUrl.trimEnd('/') + "/api/services/" + entity.substringBefore('.') + "/" + action)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.use { it.write(JSONObject().put("entity_id", entity).toString().toByteArray()) }
                val code = conn.responseCode
                runOnUiThread { callback(if (code in 200..299) "Home Assistant accepted the $action command for $entity." else "Home Assistant returned HTTP $code. Check URL, token, and entity ID.") }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { callback("Couldn't reach Home Assistant. Check that the server is on the same network and the URL is correct.") }
            }
        }
    }

    private fun askLocalModel(prompt: String, endpoint: String, callback: (String) -> Unit) {
        val memory = getSharedPreferences("jarvis_memory", MODE_PRIVATE).getString("notes", "").orEmpty()
        executor.execute {
            try {
                val url = URL(endpoint.trimEnd('/') + "/v1/chat/completions")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 120000
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                val system = "You are JARVIS, a calm, concise personal assistant. Use this user-approved local memory when relevant:\n$memory"
                val body = JSONObject()
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", prompt)))
                    .put("temperature", 0.7)
                    .put("max_tokens", 400)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val answer = if (code in 200..299) {
                    JSONObject(response).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                        ?: "The local model returned an unexpected response."
                } else "Local model returned HTTP $code. Check that llama-server is running and the endpoint is correct."
                conn.disconnect()
                runOnUiThread { callback(answer) }
            } catch (e: Exception) {
                runOnUiThread { callback("I can't reach your local AI model. Start llama-server first and set the endpoint to http://127.0.0.1:8080. Details: ${e.message ?: "connection failed"}") }
            }
        }
    }

    fun openNotificationSettings() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    override fun onDestroy() {
        speech?.destroy()
        tts?.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}
@Composable
private fun JarvisScreen(activity: MainActivity) {
    val prefs = remember {
        activity.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
    }

    var endpoint by remember {
        mutableStateOf(prefs.getString("endpoint", "http://127.0.0.1:8080") ?: "http://127.0.0.1:8080")
    }
    var haUrl by remember {
        mutableStateOf(prefs.getString("ha_url", "") ?: "")
    }
    var haToken by remember {
        mutableStateOf(prefs.getString("ha_token", "") ?: "")
    }

    var input by remember { mutableStateOf("") }
    var output by remember {
        mutableStateOf("All systems initialized. JARVIS is standing by.")
    }
    var busy by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("CORE") }
    var voiceStatus by remember { mutableStateOf("VOICE SYSTEM STANDBY") }

    val history = remember { mutableStateListOf<String>() }

    val bg = Color(0xFF030914)
    val panel = Color(0xFF0A1929)
    val panelLight = Color(0xFF10253A)
    val cyan = Color(0xFF54E7FF)
    val blue = Color(0xFF398BFF)
    val violet = Color(0xFF9274FF)
    val muted = Color(0xFF8CA9C2)

    fun sendCommand(command: String) {
        val message = command.trim()
        if (message.isBlank() || busy) return

        history.add("YOU: $message")
        input = ""
        busy = true

        activity.processCommand(message, endpoint, haUrl, haToken) { answer ->
            output = answer
            history.add("JARVIS: $answer")
            busy = false
            activity.speak(answer)
        }
    }

    fun startVoice() {
        busy = true
        voiceStatus = "LISTENING..."

        activity.listen(
            { phrase ->
                input = phrase
voiceStatus = "PROCESSING VOICE COMMAND"
busy = false
sendCommand(phrase)
            },
            { error ->
                output = error
                voiceStatus = "VOICE INPUT ERROR"
                busy = false
            }
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = cyan,
            secondary = violet,
            background = bg,
            surface = panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(bg)
                .padding(horizontal = 16.dp)
        ) {

            // TOP HEADER

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "J.A.R.V.I.S.",
                        color = cyan,
                        fontSize = 25.sp,
                        letterSpacing = 4.sp
                    )
                    Text(
                        "PERSONAL INTELLIGENCE SYSTEM",
                        color = muted,
                        fontSize = 9.sp,
                        letterSpacing = 2.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        if (busy) "● ACTIVE" else "● STANDBY",
                        color = if (busy) cyan else Color(0xFF65DCA6),
                        fontSize = 10.sp
                    )
                    Text(
                        "LOCAL AI",
                        color = muted,
                        fontSize = 9.sp,
                        letterSpacing = 2.sp
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // MAIN CONTENT

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {

                when (selectedTab) {

                    "CORE" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "NEURAL INTERFACE",
                                color = muted,
                                fontSize = 10.sp,
                                letterSpacing = 3.sp
                            )

                            Spacer(Modifier.height(8.dp))

                            NeuralCore(
                                cyan = cyan,
                                blue = blue,
                                violet = violet
                            )

                            Text(
                                when {
                                    busy -> "PROCESSING REQUEST"
                                    else -> "SYSTEM STANDING BY"
                                },
                                color = cyan,
                                fontSize = 12.sp,
                                letterSpacing = 3.sp
                            )

                            Spacer(Modifier.height(16.dp))

                            // RESPONSE PANEL

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .background(panel, RoundedCornerShape(18.dp))
                                    .padding(15.dp)
                            ) {
                                Text(
                                    "LATEST RESPONSE",
                                    color = cyan,
                                    fontSize = 10.sp,
                                    letterSpacing = 2.sp
                                )

                                Spacer(Modifier.height(10.dp))

                                Text(
                                    output,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    lineHeight = 21.sp
                                )
                            }

                            Spacer(Modifier.height(12.dp))

                            // QUICK ACTIONS

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                OutlinedButton(
                                    modifier = Modifier.weight(1f),
                                    onClick = { startVoice() }
                                ) {
                                    Text("🎙 VOICE", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    modifier = Modifier.weight(1f),
                                    onClick = { selectedTab = "CHAT" }
                                ) {
                                    Text("⌨ CHAT", fontSize = 11.sp)
                                }
                            }

                            Spacer(Modifier.height(5.dp))

                            Text(
                                "Try: Open YouTube  •  Read notifications  •  Remind me in 5 minutes to stretch",
                                color = muted,
                                fontSize = 9.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }

                    "CHAT" -> {
                        Column(Modifier.fillMaxSize()) {
                            Text(
                                "CONVERSATION",
                                color = cyan,
                                fontSize = 13.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(12.dp))

                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .background(panel, RoundedCornerShape(18.dp))
                                    .padding(13.dp)
                            ) {
                                item {
                                    Text(
                                        "JARVIS: $output",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        lineHeight = 21.sp
                                    )
                                }

                                items(history) { message ->
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        message,
                                        color = if (message.startsWith("YOU")) cyan else muted,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                }

                                if (busy) {
                                    item {
                                        Spacer(Modifier.height(12.dp))
                                        Text(
                                            "JARVIS is processing...",
                                            color = cyan,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(10.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = input,
                                    onValueChange = { input = it },
                                    modifier = Modifier.weight(1f),
                                    placeholder = {
                                        Text("Message JARVIS...")
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp)
                                )

                                Spacer(Modifier.width(7.dp))

                                Button(
                                    onClick = { sendCommand(input) },
                                    enabled = input.isNotBlank() && !busy
                                ) {
                                    Text("SEND")
                                }
                            }

                            Spacer(Modifier.height(8.dp))

                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { startVoice() }
                            ) {
                                Text("🎙 SPEAK TO JARVIS")
                            }
                        }
                    }

                    "VOICE" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "VOICE INTERFACE",
                                color = cyan,
                                fontSize = 13.sp,
                                letterSpacing = 3.sp
                            )

                            Spacer(Modifier.height(20.dp))

                            NeuralCore(
                                cyan = cyan,
                                blue = blue,
                                violet = violet
                            )

                            Text(
                                voiceStatus,
                                color = cyan,
                                fontSize = 12.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(25.dp))

                            Button(
                                onClick = { startVoice() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(55.dp)
                            ) {
                                Text("🎙  ACTIVATE MICROPHONE")
                            }

                            Spacer(Modifier.height(12.dp))

                            Text(
                                "JARVIS will process your spoken command using Android speech recognition and respond through text-to-speech.",
                                color = muted,
                                fontSize = 12.sp,
                                lineHeight = 19.sp
                            )

                            Spacer(Modifier.height(18.dp))

                            Text(
                                "LATEST TRANSCRIPTION",
                                color = cyan,
                                fontSize = 10.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(8.dp))

                            Text(
                                input.ifBlank { "Waiting for your voice command..." },
                                color = Color.White,
                                fontSize = 14.sp
                            )

                            Spacer(Modifier.height(20.dp))

                            Text(
                                "LATEST RESPONSE",
                                color = cyan,
                                fontSize = 10.sp,
                                letterSpacing = 2.sp
                            )

                            Text(
                                output,
                                color = muted,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }
                    }

                    "HOME" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 8.dp)
                        ) {
                            Text(
                                "SMART HOME CONTROL",
                                color = cyan,
                                fontSize = 13.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(15.dp))

                            Text(
                                "HOME ASSISTANT CONNECTION",
                                color = muted,
                                fontSize = 10.sp
                            )

                            Spacer(Modifier.height(8.dp))

                            OutlinedTextField(
                                value = haUrl,
                                onValueChange = {
                                    haUrl = it
                                    prefs.edit().putString("ha_url", it).apply()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("Home Assistant URL") }
                            )

                            Spacer(Modifier.height(8.dp))

                            OutlinedTextField(
                                value = haToken,
                                onValueChange = {
                                    haToken = it
                                    prefs.edit().putString("ha_token", it).apply()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("Access token") }
                            )

                            Spacer(Modifier.height(15.dp))

                            Text(
                                "QUICK COMMANDS",
                                color = cyan,
                                fontSize = 10.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(10.dp))

                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    sendCommand("home on light.living_room")
                                }
                            ) {
                                Text("TURN ON LIVING ROOM LIGHT")
                            }

                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    sendCommand("home off light.living_room")
                                }
                            ) {
                                Text("TURN OFF LIVING ROOM LIGHT")
                            }

                            Spacer(Modifier.height(15.dp))

                            Text(
                                "Replace light.living_room in these example commands with an entity ID from your Home Assistant installation.",
                                color = muted,
                                fontSize = 11.sp,
                                lineHeight = 17.sp
                            )

                            Spacer(Modifier.height(12.dp))

                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { activity.openNotificationSettings() }
                            ) {
                                Text("OPEN NOTIFICATION ACCESS SETTINGS")
                            }
                        }
                    }

                    "SYSTEM" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 8.dp)
                        ) {
                            Text(
                                "SYSTEM CONFIGURATION",
                                color = cyan,
                                fontSize = 13.sp,
                                letterSpacing = 2.sp
                            )

                            Spacer(Modifier.height(16.dp))

                            Text(
                                "LOCAL AI MODEL ENDPOINT",
                                color = muted,
                                fontSize = 10.sp
                            )

                            Spacer(Modifier.height(7.dp))

                            OutlinedTextField(
                                value = endpoint,
                                onValueChange = {
                                    endpoint = it
                                    prefs.edit().putString("endpoint", it).apply()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("http://127.0.0.1:8080") }
                            )

                            Spacer(Modifier.height(15.dp))

                            SystemPanel(
                                title = "AI ENGINE",
                                value = "Qwen local server",
                                panel = panel,
                                cyan = cyan,
                                muted = muted
                            )

                            SystemPanel(
                                title = "CONNECTION ADDRESS",
                                value = endpoint,
                                panel = panel,
                                cyan = cyan,
                                muted = muted
                            )

                            SystemPanel(
                                title = "VOICE ENGINE",
                                value = "Android Speech Recognition / Text-to-Speech",
                                panel = panel,
                                cyan = cyan,
                                muted = muted
                            )

                            SystemPanel(
                                title = "MEMORY",
                                value = "Local device storage",
                                panel = panel,
                                cyan = cyan,
                                muted = muted
                            )

                            Spacer(Modifier.height(10.dp))

                            Text(
                                "Note: These are configured system details, not live hardware or server health checks.",
                                color = muted,
                                fontSize = 10.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // BOTTOM NAVIGATION

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 8.dp)
                    .background(panel, RoundedCornerShape(18.dp))
                    .padding(vertical = 11.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val tabs = listOf(
                    "CORE" to "◉",
                    "CHAT" to "▤",
                    "VOICE" to "♫",
                    "HOME" to "⌂",
                    "SYSTEM" to "⚙"
                )

                tabs.forEach { tab ->
                    val active = selectedTab == tab.first

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedTab = tab.first },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            tab.second,
                            color = if (active) cyan else muted,
                            fontSize = 20.sp
                        )

                        Spacer(Modifier.height(3.dp))

                        Text(
                            tab.first,
                            color = if (active) cyan else muted,
                            fontSize = 8.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}


// ANIMATED NEURAL CORE

@Composable
private fun NeuralCore(
    cyan: Color,
    blue: Color,
    violet: Color
) {
    val transition = rememberInfiniteTransition(label = "jarvis_core")

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800)
        ),
        label = "pulse"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(215.dp)
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = 75.dp.toPx()

        // Outer rotating ring

        rotate(rotation) {
            drawCircle(
                color = blue.copy(alpha = 0.7f),
                radius = radius,
                center = androidx.compose.ui.geometry.Offset(cx, cy),
                style = Stroke(width = 1.5.dp.toPx())
            )

            for (i in 0 until 24) {
                val angle = i * (2.0 * PI / 24.0)
                val x = cx + radius * cos(angle).toFloat()
                val y = cy + radius * sin(angle).toFloat()

                drawCircle(
                    color = if (i % 3 == 0) cyan else blue,
                    radius = if (i % 3 == 0) 3.dp.toPx() else 1.5.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(x, y)
                )
            }
        }

        // Inner rotating ring

        rotate(-rotation * 1.4f) {
            drawCircle(
                color = violet.copy(alpha = 0.8f),
                radius = radius * 0.72f,
                center = androidx.compose.ui.geometry.Offset(cx, cy),
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = null
                )
            )

            for (i in 0 until 12) {
                val angle = i * (2.0 * PI / 12.0)
                val x = cx + radius * 0.72f * cos(angle).toFloat()
                val y = cy + radius * 0.72f * sin(angle).toFloat()

                drawCircle(
                    color = violet,
                    radius = 2.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(x, y)
                )
            }
        }

        // Neural connections

        val points = listOf(
            androidx.compose.ui.geometry.Offset(cx - 30.dp.toPx(), cy - 24.dp.toPx()),
            androidx.compose.ui.geometry.Offset(cx + 28.dp.toPx(), cy - 30.dp.toPx()),
            androidx.compose.ui.geometry.Offset(cx - 35.dp.toPx(), cy + 25.dp.toPx()),
            androidx.compose.ui.geometry.Offset(cx + 34.dp.toPx(), cy + 28.dp.toPx()),
            androidx.compose.ui.geometry.Offset(cx, cy)
        )

        val connections = listOf(
            0 to 1,
            0 to 2,
            1 to 3,
            2 to 4,
            3 to 4,
            0 to 4,
            1 to 4
        )

        connections.forEach { connection ->
            drawLine(
                color = cyan.copy(alpha = 0.5f),
                start = points[connection.first],
                end = points[connection.second],
                strokeWidth = 1.3.dp.toPx()
            )
        }

        points.forEachIndexed { index, point ->
            drawCircle(
                color = if (index == 4) cyan else blue,
                radius = if (index == 4) 4.dp.toPx() else 3.dp.toPx(),
                center = point
            )
        }

        // Central pulsing core

        drawCircle(
            color = cyan.copy(alpha = 0.12f),
            radius = 32.dp.toPx() * pulse,
            center = androidx.compose.ui.geometry.Offset(cx, cy)
        )

        drawCircle(
            color = blue.copy(alpha = 0.25f),
            radius = 22.dp.toPx() * pulse,
            center = androidx.compose.ui.geometry.Offset(cx, cy)
        )

        drawCircle(
            color = cyan,
            radius = 10.dp.toPx() * pulse,
            center = androidx.compose.ui.geometry.Offset(cx, cy)
        )

        drawCircle(
            color = Color.White.copy(alpha = 0.8f),
            radius = 3.dp.toPx(),
            center = androidx.compose.ui.geometry.Offset(cx, cy)
        )
    }
}


// REUSABLE SYSTEM INFORMATION PANEL

@Composable
private fun SystemPanel(
    title: String,
    value: String,
    panel: Color,
    cyan: Color,
    muted: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 9.dp)
            .background(panel, RoundedCornerShape(13.dp))
            .padding(13.dp)
    ) {
        Text(
            title,
            color = cyan,
            fontSize = 9.sp,
            letterSpacing = 2.sp
        )

        Spacer(Modifier.height(5.dp))

        Text(
            value,
            color = muted,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )
    }
}

        )
    }
}
