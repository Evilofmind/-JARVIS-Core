# JARVIS Core — personal local Android assistant

This is a starter Android Studio project, not a prebuilt APK. It gives you a custom dark/cyan interface, speech input, Android text-to-speech, local notes memory, app-launch commands, scheduled reminder notifications, notification-listener integration, and optional Home Assistant REST control.

## What is local, and what is not?

- Chat responses use a local `llama.cpp` OpenAI-compatible server. No paid AI API is used.
- Notes are saved in this app's private SharedPreferences.
- Speech recognition tries Android's on-device recognizer when supported; otherwise Android may use a network-backed recognition service. For strictly offline voice input, install/configure an offline recognition service or integrate a local engine such as whisper.cpp.
- Android TTS may be offline if an offline voice is installed.
- Home Assistant is optional. It must be running on your local network; the device/entity must already be configured there.
- No APK is included because APKs must be compiled and signed for installation.

## Build on your computer

1. Install Android Studio and its Android SDK / platform tools.
2. Extract this project folder.
3. In Android Studio, choose **Open** and select the `JARVIS-Core` folder.
4. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Connect your phone with USB debugging enabled, or transfer the APK to the phone and install it. Android may ask you to allow installation from that source.
8. On first launch, grant microphone and notification permissions as needed.

## Run a local model on the phone

The easiest initial experiment is Termux (no root required) with llama.cpp. Follow the official project instructions:
https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md

A typical Termux workflow is to install build tools, build llama.cpp, download a compatible GGUF model, then run the `llama-server` executable with the model. The exact binary path depends on how you built llama.cpp. Example server command once available:

`llama-server -m /path/to/model.gguf --host 127.0.0.1 --port 8080 -c 2048`

Keep context modest on phones. After the server starts, keep the endpoint field in the app as `http://127.0.0.1:8080`.

**Important:** building llama.cpp and running a model on a phone can be technically difficult and model files can be several GB. If the phone is low on RAM, the operating system may terminate the model process or performance may be very slow. Start with a small, quantized 1B–3B instruct GGUF model from a reputable model publisher, and check its license and hardware requirements.

## Run the local model on your computer instead

Install/build `llama.cpp` on your computer, download a compatible GGUF model, and start its server listening on your LAN interface, for example:

`llama-server -m /path/to/model.gguf --host 0.0.0.0 --port 8080 -c 4096`

Find your computer's LAN IP address and set the app endpoint to `http://YOUR_PC_LAN_IP:8080`. Keep both devices on the same trusted Wi-Fi network and allow the port through your computer firewall only on private networks. Do not expose this server to the public internet. Traffic is unencrypted HTTP on the LAN.

## Enable notification reading

1. Open JARVIS Core and tap **NOTIFICATIONS**.
2. Android opens Notification access settings.
3. Enable JARVIS notification access.
4. Try `read notifications`.

The service stores recent notification title/body text in process memory only. Notifications may contain private information; grant access only if you accept that. On Android, background service behavior and notification access can vary by manufacturer.

## Commands currently implemented

- `open YouTube`
- `open WhatsApp`
- `open Maps`
- `open Settings`
- `remind me in 10 minutes to drink water`
- `remember that I like concise answers`
- `what do you remember`
- `read notifications`
- `home on light.living_room`
- `home off switch.plug`

This starter uses explicit command patterns for actions. The language model itself cannot arbitrarily execute Android actions. This is intentional: it prevents model-generated text from being treated as trusted code.

## Home Assistant setup

1. Install and configure Home Assistant on a local machine/device.
2. In Home Assistant, create a long-lived access token from your user profile.
3. In JARVIS Core, enter your local Home Assistant URL (e.g. `http://192.168.1.20:8123`) and token.
4. Use the exact entity ID of a device you already own, such as `light.living_room`.

The token is stored in app preferences in this starter. Do not share the token or the project with it embedded. For production use, replace this with Android Keystore-backed encrypted storage and add confirmation before device actions.

## Limitations

- This is a starter project; it has not been compiled or tested on your specific phone.
- It does not have an always-listening wake word. Android limits persistent microphone use; use the button to start listening.
- Exact alarms may be restricted by Android settings; this starter uses `setAndAllowWhileIdle` and does not request exact timing.
- Only a small set of apps is mapped by name. Add package mappings in `MainActivity.kt` for other apps.
- Memory is simple saved notes, not automatic long-term semantic memory.
- Speech recognition and system TTS may use online services unless suitable offline language data/services are installed.
- Local AI quality and speed depend on the chosen model, phone RAM/CPU, and context size.
- The Home Assistant integration is optional and requires your own compatible devices and Home Assistant server.
- Android 8.0/API 26 or newer is required by this starter.

## Security checklist

- Keep the model server on loopback or a trusted private LAN.
- Do not port-forward the local model server.
- Never paste your Home Assistant token into chats or public repos.
- Review permissions in Android Settings and revoke any you no longer want.
